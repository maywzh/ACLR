clf = seclf
# scores = cross_val_score(clf, x_train, y_train, cv=5, scoring='accuracy')
# print('Accuracy: {:.2f} (+/- {:.2f}) [{}]'.format(scores.mean(),
#                                                     scores.std(), clf_name))
# clf.fit(x_train[:train_num], y_train[:train_num])
# y_pred = clf.predict(x_test)
# print("The classification report:\n",
#         classification_report(y_test, y_pred, target_names=label_names))